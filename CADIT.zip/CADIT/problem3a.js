
// mengakses problem3result.json yang berisi bentuk data bawaan sesuai dengan problem3datasamplejson disimpan pada problem3
const problem3 = require('./filesjon/problem3result.json')
// mengakses library fs (file system) untuk digunakan dalam mengolah file system pada lokal
const fs = require('fs')

//menggunakan setInterval untuk menjalankan program setiap waktu yang ditentukan dalam hal ini 2 menit
setInterval(function(){   

    // looping untuk memproses data problem3
    problem3.forEach((data,i)=>{

        // menampilan room pada terminal
        console.log( data.room ); 
        // mendapatkan angka random untuk temperature
        const temperaturerandom =  Math.floor((Math.random()*100)+1);
        // menampilan temperature 
        console.log( "temperature :"+ temperaturerandom  );
        // menambahkan data pada temperature
        problem3[i].temperature.push(temperaturerandom);

        // mendapatkan angka random untuk humidiy
        const humidityrandom =  Math.floor((Math.random()*100)+1);
        // menampilan humidity
        console.log( "humidity :"+humidityrandom ); 
         // menambahkan data pada humidity
        problem3[i].humidity.push(humidityrandom);
        //spasi pada terminal
        console.log( ); 

    })

   //menampilkan pada terminal untuk memastikan keluaran data baru
    console.log(problem3)
// menggunakan JSON.stringify untuk convert datanew ke string
    const jsonString = JSON.stringify(problem3)
    // menggunakan fs.writeFile untuk Write data ke ./filesjon/problem3result.json jika tidak ada maka akan membuat file json baru
    fs.writeFile('./filesjon/problem3result.json', jsonString, err => {
        if (err) {
            //jika error maka terminal akan menampilkan 'Error writing file'
            console.log('Error writing file', err)
        } else {
            // jika nberhasil maka terminal akan menampilkan "Successfully wrote file"
            console.log('Successfully wrote file')
        }
    })


 }, 2*60*1000); // set 2 menit 
 