// mengakses library fs (file system) untuk digunakan dalam mengolah file system pada lokal
const fs = require('fs')
//menggunakan setInterval untuk menjalankan program setiap waktu yang ditentukan dalam hal ini 15 menit
setInterval(function(){ 
     // menggunakan fs.readFile untuk Read data ke ./filesjon/problem3result.json 
    fs.readFile('./filesjon/problem3result.json', 'utf8', (err,problem3) => {
        if (err) {
            // jika error atau karena file tidak ada maka akan menampilkan File read failed:
            console.log("File read failed:", err)
            return
        }

        // inisialisasi AvgTotalTemperature ( untuk menjumlahkan rata-rata temperature pada semua room ) dan AvgTotalHumidity( untuk menjumlahkan rata-rata humidity pada semua room )
        let AvgTotalTemperature = 0 ,AvgTotalHumidity = 0 ;
        // JSON.parse untuk menjadikan problem3 awalnya string menjadi array
        // melakukan looping untuk proses data problem3
        JSON.parse(problem3).forEach(element => {
            console.log(element.room)
            // menampilankan min temperature dari masing masing room
            console.log("Temperature Min : "+Math.min(...element.temperature) )
             // menampilankan max temperature dari masing masing room
            console.log("Temperature Max : "+Math.max(...element.temperature) )
             // menampilankan median temperature dari masing masing room
            console.log("Temperature Median : "+medianofArray(element.temperature) )
             // menampilankan avg temperature dari masing masing room
            console.log("Temperature Avg : "+avgofArray(element.temperature) )

             // menampilankan min humidity dari masing masing room
            console.log("Humidity Min : "+Math.min(...element.humidity) )
             // menampilankan max humidity dari masing masing room
            console.log("Humidity Max : "+Math.max(...element.humidity) )
             // menampilankan median humidity dari masing masing room
            console.log("Humidity Median : "+medianofArray(element.humidity) )
             // menampilankan avg humidity dari masing masing room
            console.log("Humidity Avg : "+avgofArray(element.humidity) )
            // space pada terminal
            console.log( ); 
            // melakukan update terhadap AvgTotalTemperature dan AvgTotalHumidity
            AvgTotalTemperature +=avgofArray(element.temperature) 
            AvgTotalHumidity += avgofArray(element.humidity) 

        });
        // menampilan data pada All Room
        console.log("All Room")
        // menampilan rata rata temperature dari semua room
        console.log("Temperature Avg All Room :"+ AvgTotalTemperature/5)
        //menampilkan rata rata humidity dari semua room
        console.log("Humidity Avg All Room :"+ AvgTotalHumidity/5)

        
    })

 
  



    
    



 }, 15*60*1000); // set Interval selama 25 menit.

 function medianofArray (arr){
    const len = arr.length;
    const arrSort = arr.sort();
    const mid = Math.ceil(len / 2);
    const median = len % 2 == 0 ? (arrSort[mid] + arrSort[mid - 1]) / 2 : arrSort[mid - 1];

    return median ;
}

  function avgofArray (arr){

    const sum = arr.reduce((sum, val) => (sum += val));
    const len = arr.length;

    return sum/len ;  
}