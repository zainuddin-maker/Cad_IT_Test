
// mengakses library fs (file system) untuk digunakan dalam mengolah file system pada lokal
const fs = require('fs')
// mengakses sensor_data.json lagi disimpan pada sensordata
const sensordata = require('./filesjon/sensor_data.json')

//inisialisasi newreport , newday ,newroom  sebagai array kosong ;
// array newreport digunakan untuk membuat array baru untuk mempermudah proses.
  let newreport =[];
// array newday digunakan untuk membuat array untuk  menyimpan hari pada array
  let newday =[];
  // array newroom digunakan untuk membuat array untuk menyimpan room pada array.
  let newroom =[];

  // melakukan looping pada sensordata untuk mengolah data pada sensor_data.json untuk membentuk data array baru 
  // intinya kita membentuk array baru yang masing masing array terdiri dari hari , room , datatemperature dan data humidity
sensordata.array.forEach((data,i)=>{


                    // timeConverter merupanan fungsi untuk mengubah data waktu dari bentuk timestamp ke bentuk hari tanggal dan tahun
                    // indexOf digunakan untuk mengetahui apakah data tersebut ada didalam array atau tidak , jika ada makan keluaran nya dalah letak 
                    //dari data tersebut pada array , jika tidak maka akan keluar -1

                    // if dibawah digunakan untuk mengetahui apakah hari tersebut telah terdapat dalam array atau belum
                    if ((newday.indexOf(timeConverter(data.timestamp)) < 0)){
                        // jika belum maka kita push hari tersebut dalam newday array
                        newday.push(timeConverter(data.timestamp))
                        // mereset kembali array room untuk array yang baru
                        newroom = []
                        // push roomArea yang terbaca pada hari baru pada array newroom
                        newroom.push(data.roomArea)
                        // membuat array newreport baru
                        newreport.push({ Date : timeConverter(data.timestamp) , nameRoom : data.roomArea ,humidity :[data.humidity],temperature:[data.temperature]})
                    }
                    // dan jika pembacaaan hari tersebut telah ada pada array newday 
                    else
                    {
                        // maka akan dilakukan deteksi apakah room tersebut sudah tersimpan pada array newroom atau tidak

                        //jika room yang terbaca terdapat pada newroom array maka
                        if(newroom.indexOf(data.roomArea) < 0 ){
                            // maka push room tersebut pada newroom array
                            newroom.push(data.roomArea)
                            // lalu bikin data baru pada new report dengan hari dan room terbaca
                            newreport.push({ Date : timeConverter(data.timestamp) , nameRoom : data.roomArea,humidity :[data.humidity],temperature:[data.temperature] })
                        }
                        // jika room yang terbaca berada pada newroom maka
                        else
                        {
                          // mencari pada array keberapakah hari dan room yang terbaca pada newreport
                          const isPoint = (element) => element.nameRoom === data.roomArea && element.Date === timeConverter(data.timestamp)  ;
                         // lalu update data dari humidity dan temperaturenya
                          newreport[ newreport.findIndex(isPoint)].humidity.push(data.humidity)
                          newreport[ newreport.findIndex(isPoint)].temperature.push(data.temperature)

                        }


                    }




                    
                    
    })

    // setelah terbentuk array baru lalu siap diproses

    // dilakukan looping untuk proses setiap data pada newreport
    newreport.forEach((data,i)=>{
        // menggunakan Math.max untuk mendapatkan maksimal dari array
        // mencari max temperature dari data temperature , lalu disimpan lagi pada array newreport deengan nama maxtemperature

        newreport[i]["maxtemperature"]= Math.max( ...data.temperature )
        // mencari max humidity dari data humidity , lalu disimpan lagi pada array newreport deengan nama maxhumidity

        newreport[i]["maxhumidity"]= Math.max( ...data.humidity )

        // menggunakan Math.min untuk mendapatkan minimal  dari array
         // mencari min temperature dari data temperature , lalu disimpan lagi pada array newreport deengan nama mintemperature
        newreport[i]["mintemperature"]= Math.min( ...data.temperature )
         // mencari max humidity dari data humidity , lalu disimpan lagi pada array newreport deengan nama minhumidity
        newreport[i]["minhumidity"]= Math.min( ...data.humidity )

        // menggunakan fungsi medianofArray untuk mendapatkan median dari data array

         // mencari median temperature dari data temperature , lalu disimpan pada array newreport dengan nama mediantemperature
        newreport[i]["mediantemperature"]= medianofArray(data.temperature)

         // mencari median humidiy dari data humidity , lalu disimpan pada array newreport dengan nama medianhumidity
        newreport[i]["medianhumidity"]= medianofArray(data.humidity)

        // menggunakan fungsi avgofArray untuk mencari rata rata dari array
         // mencari avg temperature dari data temperature , lalu disimpan pada array newreport dengan nama avgtemperature
        newreport[i]["avgtemperature"]= avgofArray(data.temperature)
         // mencari avg humidity dari data humidity , lalu disimpan pada array newreport dengan nama avghumidity
        newreport[i]["avghumidity"]= avgofArray(data.humidity)

    })
   //menampilkan pada terminal untuk memastikan keluaran data baru
    console.log(newreport)
  // menggunakan JSON.stringify untuk convert datanew ke string
    const jsonString = JSON.stringify(newreport)
      // menggunakan fs.writeFile untuk Write data ke ./result_problem.json jika tidak ada maka akan membuat file json baru
    fs.writeFile('./result_problem.json', jsonString, err => {
        if (err) {
             //jika error maka terminal akan menampilkan 'Error writing file'
            console.log('Error writing file', err)
        } else {
             // jika nberhasil maka terminal akan menampilkan "Successfully wrote file"
            console.log('Successfully wrote file')
        }
    })



function timeConverter(UNIX_timestamp){
 
    var a = new Date(UNIX_timestamp );

    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];


    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
 
    var time = date + ' ' + month + ' ' + year  ;

    return time;
  }

  function medianofArray (arr){
    const len = arr.length;
    const arrSort = arr.sort();
    const mid = Math.ceil(len / 2);
    const median = len % 2 == 0 ? (arrSort[mid] + arrSort[mid - 1]) / 2 : arrSort[mid - 1];

    return median ;
}

  function avgofArray (arr){

    const sum = arr.reduce((sum, val) => (sum += val));
    const len = arr.length;

    return sum/len ;  
}

