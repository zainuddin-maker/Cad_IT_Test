// menggunakan library axios  untuk melakukan request HTTP
const axios = require('axios').default;  
// mengakses salary_data.json lagi disimpan pada salary_data
const salary_data = require('./filesjon/salary_data.json')
// mengakses library fs (file system) untuk digunakan dalam mengolah file system pada lokal
const fs = require('fs')

//inisialisasi datanew sebagai array kosong ; datanew digunakan untuk menyimpan data dari karyawan
let datanew = [];
    //gunakan axios.get untuk mendapatkan data pada https://free.currencyconverterapi.com .
    axios.get('https://free.currconv.com/api/v7/convert?q=IDR_USD&compact=ultra&apiKey=f38ffc1b3b544b1e86b4')
    .then(res => {
           
            // keluaran dari res.data
           // { IDR_USD: 0.000068710813 }
            // IDR_USD merupakan pengali yang digunakan untuk konversi IDR ke USD

            // simpan data dari pengali tersebut pada idrusd
            let idrusd = res.data.IDR_USD 

                     //gunakan axios.get untuk mendapatkan data pada http://jsonplaceholder.typicode.com/users .
                    axios.get('http://jsonplaceholder.typicode.com/users')
                    .then(res => {
                            //keluaran dari res.data merupakan array dari para karyawan lalu di simpan pada datanew
                           datanew = res.data;
                            //melakukan looping pada salaru_data , salary_data merupakan konstanta yang menyimpan data dari salary_data.json
                            // looping berguna untuk mengisi data pada datanew dengan salaryInIDR yang didapat pada salary_data.json dan juga salaryInUSD yang 
                            //didapat dari perkalian antara salaryInIDR dengan idrusd
                            salary_data.array.forEach((data,i)=>{
                            datanew[i]["salaryInIDR"] = data.salaryInIDR
                            datanew[i]["salaryInUSD"] = data.salaryInIDR* idrusd
                            })
                            //menampilkan pada terminal untuk memastikan keluaran data baru
                            console.log(datanew)

                            // menggunakan JSON.stringify untuk convert datanew ke string
                            const jsonString = JSON.stringify(datanew)
                            // menggunakan fs.writeFile untuk Write data ke ./new_salari_data.json jika tidak ada maka akan membuat file json baru
                            fs.writeFile('./new_salari_data.json', jsonString, err => {
                                if (err) {
                                    //jika error maka terminal akan menampilkan 'Error writing file'
                                    console.log('Error writing file', err)
                                } else {
                                    // jika nberhasil maka terminal akan menampilkan "Successfully wrote file"
                                    console.log('Successfully wrote file')
                                }
                            })
             

             }) 
            .catch(error => {
                 //jika error maka terminal akan menampilkan 'Access error' dan error message dari link
                    console.log("acces error", error);
                    
                });
                 }) 
  .catch(error => {
         //jika error maka terminal akan menampilkan 'Access error' dan error message dari link
            console.log("Access error", error);
            
        });

       

   
